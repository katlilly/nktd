package com.example.nathan.nktd;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Game3Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game3);
    }
}
